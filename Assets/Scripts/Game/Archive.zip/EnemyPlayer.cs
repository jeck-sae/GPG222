using UnityEngine;

public class EnemyPlayer : MonoBehaviour
{
    public PlayerData info;
    
    
}
